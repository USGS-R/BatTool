hiblkup <- function(h,...){
    tmp = hibkey[,1:4]
    names(tmp)[1] = 'Hib.no'
    View(tmp, title = 'Hib # Lookup')
}
