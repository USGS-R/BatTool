yearInf <-
function(inf.pr, reps, nyrs){

    if(is.na(inf.pr)){
        firstYear <- rep(nyrs, reps)
    } else {
        probInf <-  inf.pr * (1- inf.pr)^(1:1000 - 1)
        firstYear <- sample(x = 1:1000,
                            size = reps,
                            prob = probInf,
                            replace = TRUE)
    }
    return(firstYear)
}
