endPlot <-
function(addPlot =
                    addPlot,
                    nyrs = nyrs,
                    counts = counts,
                    mn = mn,
                    hiblimit = hiblimit,
                    tpop = tpop,
                    colr = colr,
                    colr.wn = colr.wn,
                    qe = qe,
                    cino = cino,
                    wdres = wdres
                    ){
   
    if(addPlot){
        plot(-length(counts):nyrs, c(counts,rep(NA,nyrs +1)),
             ylim = c(0, hiblimit*2), type = 'p',
             main=mn,
             xlab = 'Year (start of simulation = 0)', ylab='Population',
             col = colr, bg = 'white'
             )
    }
    
    lines(0:nyrs,
          apply(tpop[,,1], 1, 'median'), lwd=2, col=colr)
    lines(0:nyrs,
          apply(tpop[,,2], 1, 'median'), lwd=2,col=colr.wn)

    abline(h=qe, lty=3, col = gray(.7))
    
    legend(x = -length(counts),
           y = hiblimit*2,
           legend = c('Scenario 1','Scenario 2'),
           col = c(colr,colr.wn),
           lty = c(1,1),
           lwd = c(2,2))
    
    if(svalue(cino.box)==T){
        lines(0:nyrs,
              apply(tpop[,,1], 1, 'quantile', (1-cino)/2),
              lty=2, col = colr)
        lines(0:nyrs,
              apply(tpop[,,1], 1,'quantile', 1-(1-cino)/2),
              lty=2, col = colr)
        lines(0:nyrs,
              apply(tpop[,,2], 1,'quantile', (1-cino)/2),
              lty=2, col = colr.wn)
        lines(0:nyrs,
              apply(tpop[,,2], 1,'quantile', 1-(1-cino)/2),
              lty=2, col = colr.wn)
    }	

    savePlot(filename = 
             paste(wdres, 'PopulationTrendGraph', sep = '/')
             , type = "tiff")
}
