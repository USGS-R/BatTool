lkup.fun2 <- function(h,...){
    svalue(lmda.lo2) = min(svalue(lmda.lo2), 1.5)
    svalue(lmda.up2) = min(svalue(lmda.up2), 1.5)
    
    if(!is.na(svalue(lmda.lo2)) & !is.na(svalue(lmda.up2))){
        df <- lkup[lkup$lambda >= svalue(lmda.lo2) &
                   lkup$lambda<=svalue(lmda.up2),]
        up <- round(apply(df[1:13], 2, quantile, 0.975, na.rm = T), 2)
        lo <- round(apply(df[1:13], 2, quantile, 0.025, na.rm = T), 2)
        svalue(gCriParmValue[4, 1]) = paste('[',nrow(df),']',sep='')

        for(ia in 3:14){
            svalue(gCriParmValue[5,ia]) = lo[ia-1]
            svalue(gCriParmValue[6,ia]) = up[ia-1]
        }
    }
}
