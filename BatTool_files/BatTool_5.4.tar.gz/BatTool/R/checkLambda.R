checkLambda <-
function(lmda.up1, lmda.up2, lmda.lo1, lmda.lo2){
       if(is.na(svalue(lmda.up1) + svalue(lmda.up2) +
             svalue(lmda.lo1) + svalue(lmda.lo2)) ){
        return(svalue(stat.bar)<-'Enter Valid Lambda Values')
    }
}
