envStoch <-
function(pop, enst, nyrs){
    out <- pop + runif(nyrs, -enst, enst)
    ## make sure it is constrainted by 0 and 1
    out[out > 1] <- 1 
    out[out < 0] <- 0
    return(out)
}
