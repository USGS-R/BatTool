wnprobs1 <-
    function(h,...){
        fix(wnprob1)
    }
