checkNegative <- function(x){
    if(length(x)==1){
        if(x < 0){ x <- 0}
        return(x)
    } else {
        for(i in 1:length(x)){
            if(x[i] < 0){
                x[i] <- 0}
        }
        return(x)
    }   
}
