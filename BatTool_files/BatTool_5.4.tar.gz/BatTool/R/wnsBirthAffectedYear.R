wnsBirthAffectedYear <- function(wnyears,
                                 nyrs,
                                 wnBirthDecrease,
                                 reps
                                 ){
    
    wnsBirth <- matrix(0, nrow =  reps, ncol =  nyrs + 1)
    colnames(wnsBirth) <- paste("Years", 1:(nyrs + 1))
    rownames(wnsBirth) <- paste("Sample No.", 1:reps)

    wnyears[wnyears > nyrs] <- nyrs + 1
    wnyearsEnd <- wnyears + 21
    wnyearsEnd[wnyearsEnd > nyrs] <- nyrs + 1
    
    for(j in 1:reps){
        runLength <- wnyearsEnd[j] - wnyears[j]
        if(runLength > 0){
            wnsBirth[j, (wnyears[j] - 1 + (1:runLength))] <-
                as.numeric(wnBirthDecrease[1:runLength])
        }
    }
    return(wnsBirth)
}
