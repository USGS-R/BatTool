lambdaMeanCal <-
function(nyrs, reps, savePop){
    lambdaObs <- matrix(NA, nrow = (nyrs),  ncol = reps)
    for(i in 1:(nyrs)){
        lambdaObs[i,] <-
            savePop[(i+1),]/savePop[i,]
    }

    lambdaObsMean <- apply(lambdaObs, 2, mean)

    ## Remove missing values and replace them with 0s.
    lambdaObsMean[is.na(lambdaObsMean)] <- 0
    return(lambdaObsMean)
}
