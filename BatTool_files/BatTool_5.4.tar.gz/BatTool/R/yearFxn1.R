yearFxn1 = function(h,...){
        wnprobs.fxn1()
        if(!is.na(svalue(h$obj))){
            svalue(gWNS[7,2]) = NA}
    }




