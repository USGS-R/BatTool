main_pop <-
    function(
        nYears = 30,
        JWS = rep(0.9, nYears),
        AWS = rep(0.93, nYears),
        NSS = rep(0.96, nYears),
        JSS = rep(0.98, nYears),
        ASS = rep(0.99, nYears),
        PFS = rep(0.80, nYears),
        JFS = rep(0.97, nYears),
        AFS = rep(0.97, nYears),
        JP = rep(0.95, nYears),
        AP = rep(0.98, nYears),
        JB = rep(0.96, nYears),
        AB = rep(0.99, nYears),
        A0 = 1000,
        J0 = A0*0.80,
        K = 7000,
        takeParA = matrix(0, ncol = nYears, nrow = 4), # 4 rows are 4 seasons
        takeParJ = matrix(0, ncol = nYears, nrow = 4), # 4 rows are 4 seasons
        wnsSur = rep(1, nYears),
        wnBirthA = rep(0, nYears + 1),
        wnBirthJ = rep(0, nYears + 1),
        dmst = FALSE,
        genus = 'Myotis'
        ){
        
        if(genus == 'Myotis'){
            maxF = 1
        }
        if(genus == 'Lasiurus'){
            maxF = 6
        }
        if(genus == 'Pipistrelle'){
            maxF = 2
        }

        ## convert names from Lookup names to manuscript names
        
        phiWJ = JWS
        phiWA = AWS
        phiSFA = NSS
        phiSJ = JSS
        phiSA = ASS
        phiFP = PFS
        phiFJ = JFS
        phiFA = AFS
        pJ = JP
        pA = AP
        bJ = JB
        bA = AB
        phiSFJ = phiSFA
        
        Pop = matrix(NA, nrow = 2, ncol = nYears + 1)
        
        ## divide /2 is necessary because model only examines females
        ## the ceiling funciton is used ro "optimistically" round the
        ## input population size.
        Pop[,1]      <- ceiling(c(J0, A0)/2)
        PopWinter    <- matrix(NA, nrow = 2, ncol = nYears + 1)
        PopSpring    <- matrix(NA, nrow = 2, ncol = nYears + 1)
        PopSummerRep <- matrix(NA, nrow = 2, ncol = nYears + 1)
        PopFallRep   <- matrix(NA, nrow = 2, ncol = nYears + 1)
        
        PopWinter[,1] <- Pop[,1]
        
        for(y in 1:nYears){
            
            if(sum(Pop[,y]) >= K/2){
                ## A is projetion matrix for each season
                Awi <- matrix(data = c(
                                  1, 0,
                                  0, 1),
                              byrow = TRUE,
                              nrow = 2,
                              ncol = 2) * wnsSur[y]
                
                Asp <- matrix(data = c(
                                  1, 0,
                                  0, 1),
                              byrow = TRUE,
                              nrow = 2,
                              ncol = 2)
                
                AsuRep <- matrix(data = c(
                                     1, 0,
                                     0, 1),
                                 byrow = TRUE,
                                 nrow = 2,
                                 ncol = 2)
                
                AfaRep <- matrix(data = c(
                                     1, 0,
                                     0, 1),
                                 byrow = TRUE,
                                 nrow = 2,
                                 ncol = 2)
                
                AsfNR <- matrix(data = c(
                                    0, 0,
                                    0, 0),
                                byrow = TRUE,
                                nrow = 2,
                                ncol = 2)
            } else {        
                Awi <- matrix(data = c(
                                  phiWJ[y], 0,
                                  0, phiWA[y]),
                              byrow = TRUE,
                              nrow = 2,
                              ncol = 2) * wnsSur[y]
                Asp <- matrix(data = c(
                                  1, 0,
                                  0, 1),
                              byrow = TRUE,
                              nrow = 2,
                              ncol = 2)
                AfaRep <- matrix(byrow = TRUE, nrow = 2, ncol = 2,
                                 data = c(
                                     phiFP[y], phiFP[y],
                                     phiFJ[y], phiFA[y]
                                     )
                                 )
                
                AsuRep <- matrix(byrow = TRUE, nrow = 2, ncol = 2,
                                 data = c(
                                     pJ[y] * phiSJ[y] * 0.50 * (bJ[y] -
                                                                wnBirthJ[y]),
                                     pA[y] * phiSA[y] * 0.50 * (bA[y] -
                                                                wnBirthA[y]),
                                     pJ[y] * phiSJ[y],
                                     pA[y] * phiSA[y]
                                     )
                                 )
                
                AsfNR <- matrix(data = c(
                                    0, 0,
                                    (1 - pJ[y]) * phiSFJ[y],
                                    (1 - pA[y]) * phiSFA[y]
                                    ),
                                byrow = TRUE,
                                nrow = 2,
                                ncol = 2)
            }
            
            if(dmst == TRUE){
                ## Winter to spring
                PopSpring[1, y] <-
                    checkNegative(
                        sum(rbinom(n = PopWinter[1, y],
                                   size = 1,
                                   prob = Awi[1, 1])) -
                        takeParJ[1,y])
                
                PopSpring[2, y] <-
                    checkNegative(
                        sum(rbinom(n = PopWinter[2, y],
                                   size = 1,
                                   prob = Awi[2, 2])) -
                        takeParA[1,y])
                
                ## Spring to summer
                PopSummerRep[1, y] <-
                    checkNegative(
                        sum(rbinom(n = PopSpring[1, y],
                                   size = 1,
                                   prob = Asp[1, 1])) -
                        takeParJ[2,y])
                
                PopSummerRep[2, y] <-
                    checkNegative(
                        sum(rbinom(n  = PopSpring[2, y],
                                   size = 1, prob = Asp[2, 2])) -
                        takeParA[2,y])
                
                ## Summer to fall reproducing populations,
                ## births occur at this stage and first years become adults
                PopFallRep[1, y] <-
                    round(0.5 *sum(rbinom(n = round(pJ[y] * phiSJ[y] * PopSummerRep[1, y]),
                                          size = maxF,
                                          prob = (bJ[y]-wnBirthJ[y])/maxF))) +
                                              round(0.5 *sum(rbinom(n = round(pA[y] * phiSA[y] * PopSummerRep[2, y]),
                                                                    size = maxF,
                                                                    prob = (bA[y]-wnBirthA[y])/maxF)))

                PopFallRep[2, y] <-
                    checkNegative(
                        sum(rbinom(n = PopSummerRep[2, y],
                                   size = 1,
                                   prob = AsuRep[2, 2])) +
                        sum(rbinom(n = PopSummerRep[1, y],
                                   size = 1,
                                   prob = AsuRep[2, 1])) -
                        takeParJ[3,y] - takeParJ[4,y])
                
                ## Fall to winter reproducing populations and
                ## SF to winter non-reproducing populations 
                ## Fall and summer  takes are included as part of the fall to winter
                ## transition to account for losses amoung non-reproducing
                ## bats. 
                
                PopWinter[1, y + 1] <-
                    checkNegative(
                        sum(rbinom(n = PopFallRep[1, y],
                                   size = 1,
                                   prob = AfaRep[1,1])) +
                        sum(rbinom(n = PopSpring[1,y],
                                   size = 1,
                                   prob = AsfNR[1,1])) -
                        takeParJ[3,y] - takeParJ[4,y])
                
                PopWinter[2, y + 1] <-
                    checkNegative(                
                        sum(rbinom(n = PopFallRep[2, y],
                                   size = 1,
                                   prob = AfaRep[2,2])) +
                        sum(rbinom(n = PopSpring[2,y],
                                   size = 1,
                                   prob = AsfNR[2,2])) -
                        takeParA[3,y] - takeParA[4,y])
                
                Pop[, y + 1] <- PopWinter[, y + 1]            
            } else {   
                Pop[, y+1] <-
                    checkNegative(
                        ((AsfNR + (AfaRep * AsuRep)) %*%
                         (Asp %*%
                          (Awi %*% Pop[, y] -
                           c(takeParJ[1, y],
                             takeParA[1, y])) -
                          c(takeParJ[2, y], takeParA[2, y])) -
                         c(takeParJ[3, y], takeParA[3, y])) -
                        c(takeParJ[4, y], takeParA[4, y])
                        )
            }
        }
        
        tpop <- apply(Pop, 2, sum)
        
        ## the results are *2 to give the total population rather than
        ## the female population
        return(list(Population = Pop*2,
                    tpop = tpop*2)
               )
    }
