envStochFec <-
function(pop, enst, nyrs, maxF = 1){
    out <- pop + runif(nyrs, -enst, enst)
    ## make sure it is constrainted by 0 and 1
    out[out > maxF] <- maxF
    out[out < 0] <- 0
    return(out)
}
