takeParMatrix <-
function(
    witk.amt,
    witk.beg,
    witk.dur,
    sptk.amt,
    sptk.beg,
    sptk.dur,
    sutk.amt,
    sutk.beg,
    sutk.dur,
    fatk.amt,
    fatk.beg,
    fatk.dur,
    nyrs = nyrs,
    noScenarios = 2,
    saveFileOut = FALSE,
    wdres = ''){

    witk <- matrix(data = 0, nrow = noScenarios, ncol = nyrs)
    sptk <- matrix(data = 0, nrow = noScenarios, ncol = nyrs)
    sutk <- matrix(data = 0, nrow = noScenarios, ncol = nyrs)
    fatk <- matrix(data = 0, nrow = noScenarios, ncol = nyrs)

    takePar <- list()      
   
    for(i in 1:noScenarios){
        ## make sure 'duration' is not longer than simulaiton
        ## if it is, return the shortened duration period
        witk.dur[[i]] <- checkDuration(dur = witk.dur[[i]],
                                       beg = witk.beg[[i]],
                                       nyrs = nyrs)

        sutk.dur[[i]] <- checkDuration(dur = sutk.dur[[i]],
                                       beg = sutk.beg[[i]],
                                       nyrs = nyrs)
        
        sptk.dur[[i]] <- checkDuration(dur = sptk.dur[[i]],
                                       beg = sptk.beg[[i]],
                                       nyrs = nyrs)
       
        fatk.dur[[i]] <- checkDuration(dur = fatk.dur[[i]],
                                       beg = fatk.beg[[i]],
                                       nyrs = nyrs)     

       ## create season take vectors
        witk[i,] <- makeTakeVector(beg = witk.beg[[i]],
                                   amt = witk.amt[[i]],
                                   dur = witk.dur[[i]],
                                   nyrs = nyrs)
        
        sutk[i,] <- makeTakeVector(beg = sutk.beg[[i]],
                                   amt = sutk.amt[[i]],
                                   dur = sutk.dur[[i]],
                                   nyrs = nyrs)
        
        sptk[i,] <- makeTakeVector(beg = sptk.beg[[i]],
                                   amt = sptk.amt[[i]],
                                   dur = sptk.dur[[i]],
                                   nyrs = nyrs)
        
        fatk[i,] <- makeTakeVector(beg = fatk.beg[[i]],
                                   amt = fatk.amt[[i]],
                                   dur = fatk.dur[[i]],
                                   nyrs = nyrs)

       ## create output matrix and then save it.
        
        takePar[[i]] <- rbind(witk[i,], sptk[i,], sutk[i,], fatk[i,])
        rownames(takePar[[i]]) <- c("Winter", "Spring", "Summer", "Fall")
        colnames(takePar[[i]]) <- paste("Years", 1:nyrs)
       
       if(saveFileOut == TRUE){
           write.csv(takePar[[i]],
                     paste(wdres,
                           paste('Scenarios_', i,
                                 '_take_parameters.csv',
                                 sep = ''),
                           sep='/'),
                     quote=F, row.names=T)
       }

   }
    return(takePar)
}
