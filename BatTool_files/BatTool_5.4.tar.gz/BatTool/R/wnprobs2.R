wnprobs2 <-
    function(h,...){
        fix(wnprob2)
    }
