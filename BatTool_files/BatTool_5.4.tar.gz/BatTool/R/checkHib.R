checkHib <-
function(hibno, hibkey){
    if(is.na(hibno)){
        return(svalue(stat.bar) <- 'Enter Valid Hibernaculum Number')
    }
    if(nrow(hibkey[hibkey$Hib.ID==hibno,])==0){
        return(svalue(stat.bar) <- 'Enter Valid Hibernaculum Number')}
}
