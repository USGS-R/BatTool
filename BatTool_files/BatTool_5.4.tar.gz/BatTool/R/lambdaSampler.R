lambdaSampler <-
    function(lkup,
             lambda.lo,
             lambda.up,
             reps){
        
        ## Extract desired lambda values
        df = lkup[lkup$lambda>=lambda.lo & lkup$lambda<=lambda.up,]
        
        ##If more rows than reps, no replacment
        ifelse(nrow(df)> reps,
               replace <- FALSE,
               replace <- TRUE)
        
        par.row = sample(nrow(df),reps,replace=replace)
        lambdaTableUse <- df[par.row,]
        return(lambdaTableUse)
    }
