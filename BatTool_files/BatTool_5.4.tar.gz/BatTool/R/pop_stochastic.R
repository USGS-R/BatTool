pop_stochastic <- function(
    reps = 3,
    lambda.lo = 1,
    lambda.up = 1,
    enst = 0.1,
    nYears = 30,
    A0 = 1000,
    J0 = A0 * 0.8,
    K = 7000,
    takeParA = matrix(0, ncol = nYears, nrow = 4),
    takeParJ = matrix(0, ncol = nYears, nrow = 4),
    wnsSur = matrix(rep(1, nYears), ncol = (nYears), nrow = reps),
    wnBirthA = rep(0, nYears + 1),
    wnBirthJ = rep(0, nYears + 1),
    dmst = FALSE,
    genus = "Myotis"
    ) 
{
    if(genus == "Myotis") {
        data(lkup)
        maxF = 1
    }
    if(genus == "Lasiurus") {
        data(HoaryLookUpTable)
        lkup <- LookUpTable
        maxF = 6
    }
    if(genus == "Pipistrelle") {
        data(PipLookUpTable)
        lkup <- LookUpTable
        maxF = 2
    }
    p <- lambdaSampler(lkup = lkup, lambda.lo = lambda.lo,
                       lambda.up = lambda.up, 
                       reps = reps)
    
    tpop <- matrix(NA, (nYears + 1), reps)

    for (ireps in 1:reps) {        
        aws <- envStoch(p$AWS[ireps], enst, nYears)
        jws <- envStoch(p$JWS[ireps], enst, nYears)
        ap <- envStoch(p$AP[ireps], enst, nYears)
        jp <- envStoch(p$JP[ireps], enst, nYears)
        ass <- envStoch(p$ASS[ireps], enst, nYears)
        nss <- envStoch(p$NSS[ireps], enst, nYears)
        jss <- envStoch(p$JSS[ireps], enst, nYears)
        ab <- envStochFec(p$AB[ireps], enst, nYears, maxF)
        jb <- envStochFec(p$JB[ireps], enst, nYears, maxF)
        afs <- envStoch(p$AFS[ireps], enst, nYears)
        jfs <- envStoch(p$JFS[ireps], enst, nYears)
        pfs <- envStoch(p$PFS[ireps], enst, nYears)
        tpop[, ireps] <- main_pop(JWS = jws, AWS = aws, AP = ap, 
                                  JP = jp, ASS = ass, NSS = nss,
                                  JSS = jss, AB = ab, 
                                  JB = jb, AFS = afs, JFS = jfs,
                                  PFS = pfs, A0 = A0, 
                                  J0 = J0, nYears = nYears, K = K,
                                  takeParA = takeParA, 
                                  takeParJ = takeParJ,
                                  wnsSur = wnsSur[ireps, ], 
                                  wnBirthA = wnBirthA,
                                  wnBirthJ = wnBirthJ,
                                  dmst = dmst, 
                                  genus = genus)$tpop
    }
    TpopOut <- t(tpop)
    rownames(TpopOut) <- paste("Sample", 1:reps)
    colnames(TpopOut) <- paste("Year", 0:nYears)
    popSummary <- rbind(apply(TpopOut, 2, FUN = quantile, 0.025), 
                        apply(TpopOut, 2, FUN = mean),
                        apply(TpopOut, 2, FUN = quantile, 
                              0.975))
    rownames(popSummary) <- c("0.025 quantile", "Mean", "0.975 quantile")
    return(list(wnsSurvival = wnsSur, tpop = TpopOut, popSummary = popSummary))
}
