wnprobs.fxn1=function(h,...){
    if(svalue(gWNS[4,5], index=T) == 1){
        wnprob1 <<- wnprob.lbb  # placeholder, not used in sims
        ## names(wnprob1)[1] <<- 'Scenario1'
        svalue(gWNS[7,2]) = NA
        svalue(gWNS[8,2]) = NA
    }
    if(svalue(gWNS[4,5],index = T) == 2){
        wnprob1 <<- wnprob.lbb
        ## names(wnprob1)[1] <<- 'Scenario1'
        svalue(gWNS[7,2]) = 0.096
        svalue(gWNS[8,2]) = NA
    }
    if(svalue(gWNS[4,5], index=T)==3){
        wnprob1 <<- wnprob.ib ## I think this needs to be added in to fix a bug
        ## Check to see if WN arrival date given
        if(
            length(which(wnbeginyear$Hib.ID == svalue(hib.num))) > 0
            ){ 
            svalue(gWNS[8, 2]) = wnbeginyear$year.of.wn.infection[
                      wnbeginyear$Hib.ID == svalue(hib.num)] -
                          as.numeric(lastobs)
            if(is.na(svalue(gWNS[8, 2]))){
                svalue(gWNS[7, 2]) = 0.096
            } else{
                svalue(gWNS[7, 2]) = NA
            }
        } else{
            svalue(gWNS[8, 2]) = NA
            svalue(gWNS[7, 2]) = 0.096
        }
    }
        if(svalue(gWNS[4,5],index = T) == 4){
        wnprob1 <<- wnprob.other1
        ## names(wnprob1)[1] <<- 'Scenario1'
        svalue(gWNS[7,2]) = 0.096
        svalue(gWNS[8,2]) = NA
    }
        if(svalue(gWNS[4,5],index = T) == 5){
        wnprob1 <<- wnprob.other2
        ## names(wnprob1)[1] <<- 'Scenario1'
        svalue(gWNS[7,2]) = 0.096
        svalue(gWNS[8,2]) = NA
    }

    
}           
