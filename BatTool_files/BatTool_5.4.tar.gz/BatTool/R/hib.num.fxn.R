## This function updates input values after the parameter
## after the hibernacula number is changed. 

hib.num.fxn <- function(h){
    hibno <<- svalue(hib.num)
    if(is.na(hibno)){return()}

    hibno.row = which(hibkey$Hib.ID ==hibno)
    
    svalue(window) = hiblabel = paste(
                         'Hib #',hibno,', ',
                         hibkey$Hibernaculum.Name[hibno.row],', ',
                         hibkey$County[hibno.row],' County, ',
                         hibkey$State[hibno.row],' -- ','RU#',
                         hibkey$rec.unit[hibno.row],sep = '')

    svalue(grph.nm) = paste(
              hibkey$Hibernaculum.Name[hibno.row],', ',
              hibkey$County[hibno.row],' County, ',
              hibkey$State[hibno.row],sep = '')

    hiblimit.mandf = round(
        1.5*(
            max(
                c(
                    as.numeric(
                        hibkey[hibkey$Hib.ID==hibno,
                               paste('yr', 1929:2020, sep = '')]),
                    0),na.rm = T)))
    
    ## Temp is the modeled starting population
    ## This comes from the 2012 Thogmartin et al. paper:
    ## Population-level impact of white-nose syndrome on the endangered
    ## Indiana bat
    ## the 27 is the number of years before the inflection point
    ## and 8 are the years after the inflection point

    temp = round(exp(ests$int.hib[hibno.row] + ests$yr.hib[hibno.row] * 27 +
        ests$yr0309.hib[hibno.row] * 8))
    
    if(is.na(temp)){temp = 0}
    ## MAY NEED TO CHANGE THIS IF STATEMENT
    if(temp > hiblimit.mandf){temp = hiblimit.mandf}

    temp1 = hibkey[ hibno.row, paste('yr', 1929:2020, sep = '')]
    t1w = which(!is.na(temp1))
    temp1 = temp1[t1w]
    temp1 = temp1[length(temp1)]

    if(length(temp1) == 0){temp1 = 0; names(temp1) = '  NA  '}
    lastobs <<- substr(names( temp1), 3, 6)
    print("Last Observed year")
    print(lastobs)
    spops = paste(
        '(',round(temp), '-Modeled, ','  ',
        temp1,'-Obs', lastobs,')',sep='')
    svalue(spop.lab) = paste('Starting Population =',
              spops)
    ### I think this IF then needed to be changed to make the model behave
    if(temp1 == 0){temp1 = temp}
    svalue(spop.amt) = as.numeric(temp1)
    svalue(hlim.amt) = hiblimit.mandf
    r16.ests=
        round((
            c( ests[ests$ID == hibno, 'yr.hib'],
              ests[ ests$ID == hibno, 'yr.cl'],
              ests[ ests$ID == hibno, 'yr.ru'],
              ests[ ests$ID == hibno, 'yr.sp']
              )),3)
    r16.ses = round( (c( ests[ ests$ID == hibno, 'yr.hib.se'],
        ests[ ests$ID == hibno, 'yr.cl.se'],
        ests[ ests$ID == hibno, 'yr.ru.se'],
        ests[ ests$ID == hibno, 'yr.sp.se'])), 3)
    r16.ciup = round( exp(r16.ests + r16.ses), 3)
    r16.cilo = round( exp(r16.ests - r16.ses), 3)
    
    LambdaEst   <<- round(exp(r16.ests),3)
    LambdaEstLo <<- round(r16.cilo,3)
    LambdaEstUp <<- round(r16.ciup,3)
    hibLambdaList = paste(
        LambdaEst,
        ' (', LambdaEstLo,' - ', LambdaEstUp,') ' ,
        lambdaScn, sep='')            
    gLambdaScn[2,1][] = gLambdaScn[2,4][] = hibLambdaList
    enabled(run.but) = T

    ##update the wn begin year
    if(hibno > 900){ # scenarios >900 assumed to be dummy dataset
        wnby = NA
        ## svalue(yrwn.inf1) = wnby 
        ## svalue(yrwn.inf2) = wnby
    }else{
        wnby = with(wnbeginyear, year.of.wn.infection[Hib.ID == hibno])
        ## svalue(yrwn.inf1) = wnby - as.numeric(lastobs)
        ## svalue(yrwn.inf2) = wnby - as.numeric(lastobs)
    }

    ## Set Take parameters so they change based upon hibernacula 
    svalue(sptk.beg1) = hibkey[hibkey$Hib.ID==hibno, "sptk.beg"]
    svalue(sptk.amt1) = hibkey[hibkey$Hib.ID==hibno, "sptk.amt"]
    svalue(sptk.dur1) = hibkey[hibkey$Hib.ID==hibno, "sptk.dur"]

    svalue(sptk.beg2) = hibkey[hibkey$Hib.ID==hibno, "sptk.beg"]
    svalue(sptk.amt2) = hibkey[hibkey$Hib.ID==hibno, "sptk.amt"]
    svalue(sptk.dur2) = hibkey[hibkey$Hib.ID==hibno, "sptk.dur"]

    svalue(witk.beg1) = hibkey[hibkey$Hib.ID==hibno, "witk.beg"]
    svalue(witk.amt1) = hibkey[hibkey$Hib.ID==hibno, "witk.amt"]
    svalue(witk.dur1) = hibkey[hibkey$Hib.ID==hibno, "witk.dur"]

    svalue(witk.beg2) = hibkey[hibkey$Hib.ID==hibno, "witk.beg"]
    svalue(witk.amt2) = hibkey[hibkey$Hib.ID==hibno, "witk.amt"]
    svalue(witk.dur2) = hibkey[hibkey$Hib.ID==hibno, "witk.dur"]

    svalue(fatk.beg1) = hibkey[hibkey$Hib.ID==hibno, "fatk.beg"]
    svalue(fatk.amt1) = hibkey[hibkey$Hib.ID==hibno, "fatk.amt"]
    svalue(fatk.dur1) = hibkey[hibkey$Hib.ID==hibno, "fatk.dur"]

    svalue(fatk.beg2) = hibkey[hibkey$Hib.ID==hibno, "fatk.beg"]
    svalue(fatk.amt2) = hibkey[hibkey$Hib.ID==hibno, "fatk.amt"]
    svalue(fatk.dur2) = hibkey[hibkey$Hib.ID==hibno, "fatk.dur"]

    svalue(sutk.beg1) = hibkey[hibkey$Hib.ID==hibno, "sutk.beg"]
    svalue(sutk.amt1) = hibkey[hibkey$Hib.ID==hibno, "sutk.amt"]
    svalue(sutk.dur1) = hibkey[hibkey$Hib.ID==hibno, "sutk.dur"]
    
    svalue(sutk.beg2) = hibkey[hibkey$Hib.ID==hibno, "sutk.beg"]
    svalue(sutk.amt2) = hibkey[hibkey$Hib.ID==hibno, "sutk.amt"]
    svalue(sutk.dur2) = hibkey[hibkey$Hib.ID==hibno, "sutk.dur"]

    svalue(gWNS[7,2]) = NA
    svalue(gWNS[8,2]) = NA
    svalue(gWNS[7,3]) = .096
    svalue(gWNS[8,3]) = NA
    svalue(gWNS[4,5],index = T) = 1
    svalue(gWNS[5,5],index = T) = 3
}
