WNS_input <-
    function(
        inf.pr,
        yrwn.inf = NA,
        reps,
        nyrs
        ){
        
        wnstart <- numeric(reps)
        ifelse(is.na(yrwn.inf) == FALSE,
               wnstart <- rep(yrwn.inf, reps),
               wnstart <- yearInf(inf.pr = inf.pr, reps = reps, nyrs = nyrs)
               )
        return(wnstart)
    }
