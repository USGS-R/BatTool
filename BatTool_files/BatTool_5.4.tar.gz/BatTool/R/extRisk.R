extRisk <- function(tpop, extLevel = 0){
    nYears = dim(tpop)[2]-1
    extRisk <- numeric(nYears + 1)
    names(extRisk) <- paste("Year", 0: nYears)

    ## Calculate the risk of extinction for any year
    for(year in 1:(nYears+1)){
        dieOff <- which(tpop[,year] <= extLevel)
        extRisk[year] <-
            length(dieOff)/length(tpop[,year])
        if(extRisk[year]>0){
            tpop[dieOff,year:(nYears+1)] <- 0
        }
    }

    
    ## Calcualte the time to extinction
    nSamples = dim(tpop)[1]
    samDieOff <- which(apply(tpop, 1, min) <= extLevel)

    meanExtTime <- numeric(nSamples)
    meanExtTime <- NA
    for(sample in samDieOff){
        meanExtTime[sample] <- min(which(tpop[sample,]<= extLevel))
    }
    TimeToExt <- 
        quantile(meanExtTime, probs = c(0.025, 0.5, 0.975), na.rm = TRUE)
    return(list("TimeToExt" = TimeToExt,
                "ExtRisk" = extRisk)
                )
}
