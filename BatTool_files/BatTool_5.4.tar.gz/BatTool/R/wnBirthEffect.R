wnBirthEffect <-
    function(wnyears,
             nyrs,
             wnprob,
             AgeClass = 'A',
             reps){
        wnsBirth <- matrix(0, nrow =  reps, ncol =  nyrs + 1)
        ifelse(AgeClass == 'A',
               AgeClassVar <- 3,
               AgeClassVar <- 4)
        if(min(wnyears) >= 0){
            wnsBirth <- wnsBirthAffectedYear(
                wnyears = wnyears,
                nyrs = nyrs,
                wnBirthDecrease = wnprob[AgeClassVar, ],
                reps = reps)
        } else {
            wnsBirthTemp <- wnsBirthAffectedYear(
                wnyears = rep(1, length(wnyears)),
                nyrs = nyrs,
                wnBirthDecrease = wnprob[AgeClassVar, ],
                reps = reps)[, -c(1:(-wnyears[1]))]
            wnsBirth[, 1:(dim(wnsBirthTemp)[2])]  <-
                wnsBirthTemp
        }
        return(wnsBirth)
    }
