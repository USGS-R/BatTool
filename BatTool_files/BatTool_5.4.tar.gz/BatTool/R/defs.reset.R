defs.reset <-
    function(h, ...){
        svalue(gLambdaScn[2,1], index = T) = 2
        svalue(gLambdaScn[2,4], index = T) = 2
        svalue(nyrs.amt) = 50
        svalue(reps.amt) = 1000
        svalue(cino.amt) = '95'
        svalue(col.box,index = T) = 1
        svalue(adpr.amt1) = svalue(adpr.amt2) = 0.8
        svalue(enst.amt1) = svalue(enst.amt2) = 0.04
        svalue(dmst.box1) = svalue(dmst.box2) = T
        svalue(fnam) = 'temp'
        svalue(gWNS[7,2]) = NA
        svalue(gWNS[8,2]) = NA
        svalue(gWNS[7,3]) = .096
        svalue(gWNS[8,3]) = NA
        svalue(gWNS[4,5],index = T) = 1
        svalue(gWNS[5,5],index = T) = 3
        wnprob2 <<- wnprob.ib
        names(wnprob2)[1] <<- 'Scenario2'
        wnprob1<<-wnprob.lbb
        names(wnprob1)[1] <<- 'Scenario1'
        hib.num.fxn()
    }
