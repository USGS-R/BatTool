makeTakeVector <-
function(beg,
                           amt,
                           dur,
                           nyrs = nyrs){
    out <- numeric(nyrs)

    if(beg ==0){beg <- 1}
    out <- c(
        rep(0, beg - 1),
        rep(amt, dur),
        rep(0, nyrs - dur - beg + 1)
        )
    return(out)
}
