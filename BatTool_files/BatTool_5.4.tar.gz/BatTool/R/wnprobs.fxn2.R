wnprobs.fxn2=function(h,...){
    if(svalue(gWNS[5,5],index=T)==1){
        wnprob2 <<- wnprob.lbb # defualt, not used in sims
        ## names(wnprob2)[1] <<-'Scenario2'
        svalue(gWNS[7,3])=NA
        svalue(gWNS[8,3])=NA
    }
    if(svalue(gWNS[5,5],index=T)==2){
        wnprob2 <<- wnprob.lbb
        ## names(wnprob2)[1] <<-'Scenario2'
        svalue(gWNS[7,3]) = 0.096
        svalue(gWNS[8, 3]) = NA
    }
    if(svalue(gWNS[5,5],index=T)==3){
        wnprob2 <<- wnprob.ib ## I think this needs to be added in to fix a bug
       ## Check to see if WN arrival date given
        if(
            length(which(wnbeginyear$Hib.ID == svalue(hib.num))) > 0
            ){ 
            svalue(gWNS[8, 3]) = wnbeginyear$year.of.wn.infection[
                      wnbeginyear$Hib.ID == svalue(hib.num)] -
                          as.numeric(lastobs)
            if(is.na(svalue(gWNS[8, 3]))){
                svalue(gWNS[7, 3]) = 0.096
            } else{
                svalue(gWNS[7, 3]) = NA
            }
        } else{
            svalue(gWNS[8, 3]) = NA
            svalue(gWNS[7, 3]) = 0.096
        }
    }
    if(svalue(gWNS[5,5],index=T)==4){
        wnprob2 <<- wnprob.other1
        ## names(wnprob2)[1] <<-'Scenario2'
        svalue(gWNS[7,3]) = 0.096
        svalue(gWNS[8, 3]) = NA
    }
        if(svalue(gWNS[5,5],index=T)==5){
        wnprob2 <<- wnprob.other2
        ## names(wnprob2)[1] <<-'Scenario2'
        svalue(gWNS[7,3]) = 0.096
        svalue(gWNS[8, 3]) = NA
    }
}
