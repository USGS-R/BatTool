saveInitialCondition <-
function(
    nam,
    mn,
    takePar,
    enst,
    dmst,
    adpr.st,
    nyrs,
    tpop,
    qe,
    wdres,
    lambdaTableUse,
    lambdaObsMean,
    reps
    ){
    
    sink(file=paste(wdres, 'Results summary.txt', sep = '/'))
    cat(paste("Results file name:", nam), "\n")
    cat(paste("Hibernacula modeled:", mn), "\n")
    cat('Inputs:', "\n")

    for(sc in 1:2){
        cat(paste('Scenario ', sc, '--', sep = ""), "\n")
        apply(X = lambdaTableUse[[sc]][,-c(1:2)], 2,
              FUN = quantile, c(0.025, 0.975))
        cat('Seasonal take parameters:', "\n")
        print( takePar[[sc]] )

        cat(paste('Env. Stoch.:', enst[[sc]],
                  '    Dem. Stoc.:' ,dmst[[sc]],
                  '   Proportion of staring adults: ', adpr.st[[sc]],
                  sep=''), "\n")
        
        cat('Output:', "\n")
        
        cat(
            paste('Scenario ', sc, ' population at year ',
                  nyrs, ':  ',round(median(tpop[,nyrs+1, sc]))
                  ,
                  ' (95% CI: ',
                  round(quantile(tpop[, dim(tpop)[2], sc], 0.025, type=3)),
                  ' to ',
                  round(quantile(tpop[, dim(tpop)[2], sc], 0.975, type=3)),
                  ')',
                  sep='')
            , "\n")
        
        cat(
            paste('Scenario ', sc,
                  ' simulated lambda over the next ',
                  nyrs, " years: ",
                  signif(mean(lambdaObsMean[[sc]]), 3),
                  ' (95% CI: ',
                  signif(quantile(lambdaObsMean[[sc]], 0.025), 3),
                  ' to ',
                  signif(quantile(lambdaObsMean[[sc]], 0.975), 3),
                  ")",
                  sep = "")
            , "\n")
        
        cat(
            paste('Scenario',  sc,
                  'Probability of population being less than:')
            , "\n")
        qYears <- round(c(0, nyrs/5, nyrs/2, nyrs), 0) + 1 
        qeData <- data.frame(matrix(NA, ncol = length(qYears),
                                    nrow = length(qe)))
        colnames(qeData) <- paste('Year', qYears - 1)
        rownames(qeData) <- paste('Threshold of', qe)
        for(j in 1:length(qe)){
            for(i in 1:length(qYears)){
                qeData[j, i] <- round(
                    length(which(tpop[qYears[i], , sc] <= qe[j]))/reps, 2)
            }
        }
    
        print(qeData)
    }
        sink()
}
