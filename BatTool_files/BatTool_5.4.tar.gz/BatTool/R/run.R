run <- function(h,...){
    ## Create directory to store data in
    nam = svalue(fnam)
    ResName = 'Results'
    dir.create(ResName, showWarnings = FALSE)
    wdres = paste(ResName, nam, sep = '/')
    dir.create(wdres, showWarnings = FALSE)   

    ## extract out the simulation parameters
    hibno <<- svalue(hib.num) # hibernacula number

    ## Check the hibernacula and lambda values
    checkHib(hibno, hibkey)
    checkLambda(lmda.up1, lmda.up2, lmda.lo1, lmda.lo2)  

    witk.dur = list(
        witk.dur1 = as.numeric(svalue(witk.dur1)),
        witk.dur2 = as.numeric(svalue(witk.dur2))
        ) # Winter take duration

    sutk.dur = list(
        sutk.dur1 = as.numeric(svalue(sutk.dur1)),
        sutk.dur2 = as.numeric(svalue(sutk.dur2))
        )# Summer take duration

    sptk.dur = list(
        sptk.dur1 = as.numeric(svalue(sptk.dur1)),
        sptk.dur2 = as.numeric(svalue(sptk.dur2))
        ) # Spring take duration

    fatk.dur = list(
        fatk.dur1 = as.numeric(svalue(fatk.dur1)),
        fatk.dur2 = as.numeric(svalue(fatk.dur2))
        ) # Fall take duration

    witk.beg = list(
        witk.beg1 = as.numeric(svalue(witk.beg1)),
        witk.beg2 = as.numeric(svalue(witk.beg2))
        ) # begining of winter take

    sutk.beg = list(
        sutk.beg1 = as.numeric(svalue(sutk.beg1)),
        sutk.beg2 = as.numeric(svalue(sutk.beg2))
        )# begining of summer take

    sptk.beg = list(
        sptk.beg1 = as.numeric(svalue(sptk.beg1)),
        sptk.beg2 = as.numeric(svalue(sptk.beg2))
        ) # beging of spring take

    fatk.beg = list(
        fatk.beg1 = as.numeric(svalue(fatk.beg1)),
        fatk.beg2 = as.numeric(svalue(fatk.beg2))
        )# begning of fall take

    witk.amt = list(
        witk.amt1 = as.numeric(svalue(witk.amt1)),
        witk.amt2 = as.numeric(svalue(witk.amt2))
        ) # winter take amount

    sutk.amt = list(
        sutk.amt1 = as.numeric(svalue(sutk.amt1)),
        sutk.amt2 = as.numeric(svalue(sutk.amt2))
        ) # summer take amount

    sptk.amt = list(
        sptk.amt1 = as.numeric(svalue(sptk.amt1)),
        sptk.amt2 = as.numeric(svalue(sptk.amt2))
        ) # spring take amount

    fatk.amt = list(
        fatk.amt1 = as.numeric(svalue(fatk.amt1)),
        fatk.amt2 = as.numeric(svalue(fatk.amt2))
        ) # fall take amount
    
    
    nyrs = svalue(nyrs.amt) #how many years to run the simulation
    reps = svalue(reps.amt) #how many simulations (REPlicates)
    startpop = svalue(spop.amt) #number of females
    hiblimit = svalue(hlim.amt) # carrying capacity
    cino = svalue(cino.amt)/100 # confidence intervals for graph
    
    pb = tkProgressBar(title='Running...',min=0,max=reps*2,width=800)	
    
    lambda.up <- c(svalue(lmda.up1), svalue(lmda.up2)) # upper lambda value
    lambda.lo <- c(svalue(lmda.lo1), svalue(lmda.lo2)) # lower lambda value
    
    adpr.st <- c(svalue(adpr.amt1), svalue(adpr.amt2)) # adult start propotion
    enst <- c(svalue(enst.amt1), svalue(enst.amt2)) #env  stochasticity
    dmst <- c(svalue(dmst.box1), svalue(dmst.box2)) #demo stochasticity

    takePar <- takeParMatrix(witk.amt = witk.amt,
                             witk.beg = witk.beg,
                             witk.dur = witk.dur,
                             sptk.amt = sptk.amt,
                             sptk.beg = sptk.beg,
                             sptk.dur = sptk.dur,
                             sutk.amt = sutk.amt,
                             sutk.beg = sutk.beg,
                             sutk.dur = sutk.dur,
                             fatk.amt = fatk.amt,
                             fatk.beg = fatk.beg,
                             fatk.dur = fatk.dur,
                             nyrs = nyrs,
                             noScenarios = 2,
                             saveFileOut = TRUE,
                             wdres = wdres) # take parameters


    ## WNS input parameter
    inf.pr   <- c(svalue(gWNS[7,2]),
                  svalue(gWNS[7,3]))

    yrwn.inf <- c(svalue(gWNS[8,2]),
                  svalue(gWNS[8,3]))

    wnyears <- list()
    wnsSur <- list()
    wnBirthA <- list()
    wnBirthJ <- list()

    tpop <- array(data = NA,
                  dim=c(nyrs + 1, reps, 2),
                  dimnames = c("Years", "Reps", "Scenarios")
                  )
                      
    lambdaTableUse <- list()
    lambdaObsMean <- list()

    wnprob <- list()
    wnprob[[1]] <- wnprob1
    wnprob[[2]] <- wnprob2

    ## Create WNS tables
    ScnWNSData <- c(svalue(gWNS[4, 5]),
                    svalue(gWNS[5, 5])) 

    
    
    
    for(sc in 1:2){##run the two scenarios
        wnyears[[sc]] <- WNS_input(inf.pr =inf.pr[sc],
                                   yrwn.inf = yrwn.inf[sc],
                                   reps = reps,
                                   nyrs = nyrs)
        
        wnsSur[[sc]] <- wnsSurvGenerator(wnyears = wnyears[[sc]],
                                         reps = reps,
                                         nyrs = nyrs,
                                         wnprob = wnprob[[sc]])

        wnBirthA[[sc]] <- wnBirthEffect(wnyears = wnyears[[sc]],
                                        nyrs = nyrs,
                                        wnprob = wnprob[[sc]],
                                        AgeClass = "A",
                                        reps = reps)
        
        wnBirthJ[[sc]] <- wnBirthEffect(wnyears = wnyears[[sc]],
                                        nyrs = nyrs,
                                        wnprob = wnprob[[sc]],
                                        AgeClass = "J",
                                        reps = reps)
            
        write.csv(wnsSur[[sc]],
                  paste(wdres,
                        paste('Scenario ', sc,
                              ' whitenose survival probabilities.csv',
                              sep=''),
                        sep = '/'),
                  row.names = TRUE, quote = FALSE)
        
        ##creates a data frame of parameters based upon lambda
        lambdaTableUse[[sc]] <- lambdaSampler(lkup = lkup,
                                        lambda.lo = lambda.lo[sc],
                                        lambda.up = lambda.up[sc],
                                        reps = reps)

        lambdaTableUse[[sc]][,1] <- 1:reps
        colnames(lambdaTableUse[[sc]])[1] <- "Sim No."
        write.csv(x = lambdaTableUse[[sc]],
                  file =
                  paste(wdres, paste("ParameterValuesScenario__",
                                     sc, ".csv", sep = ""),
                        sep = "/"),
                  quote = FALSE,
                  row.names = FALSE
                  )
          
        ## Run simulations
        for(ireps in 1:reps){
            svalue(stat.bar) = paste('Ran', ireps,
                      'simulations', 'for Scenario', sc) #update status bar
            
            flush.console()
            gireps <- ireps + ((sc-1)*reps)
            setTkProgressBar(pb, gireps)

            apop = round(startpop * adpr.st[sc]) ##adult starting population 
            jpop = round(startpop - apop) ##juv starting population 
            adpr = adpr.st[sc] ##adpr is reset to adpr.st from the widget	
            p = lambdaTableUse[[sc]][ireps,] 

            ## generate env. stochasticity around each parameter
            aws  <- envStoch(p$AWS, enst[sc], nyrs)
            jws  <- envStoch(p$JWS, enst[sc], nyrs)
            ap   <- envStoch(p$AP,  enst[sc], nyrs)
            jp   <- envStoch(p$JP,  enst[sc], nyrs)
            ass  <- envStoch(p$ASS, enst[sc], nyrs)
            nss  <- envStoch(p$NSS, enst[sc], nyrs)
            jss  <- envStoch(p$JSS, enst[sc], nyrs)
            ab   <- envStochFec(p$AB,  enst[sc], nyrs, maxF = 1)
            jb   <- envStochFec(p$JB,  enst[sc], nyrs, maxF = 1)
            afs  <- envStoch(p$AFS, enst[sc], nyrs)
            jfs  <- envStoch(p$JFS, enst[sc], nyrs)
            pfs  <- envStoch(p$PFS, enst[sc], nyrs)

            ## main population model
            tpop[,ireps, sc] <- main_pop(
                JWS = jws,
                AWS = aws,
                AP = ap,
                JP = jp,
                ASS = ass,
                NSS = nss,
                JSS = jss,
                AB = ab,
                JB = jb,
                AFS = afs,
                JFS = jfs,
                PFS = pfs,
                A0 = apop,
                J0 = jpop,
                nYears = nyrs,
                K = hiblimit,
                takeParA = takePar[[sc]],
                wnsSur = wnsSur[[sc]][ireps,],
                wnBirthA = wnBirthA[[sc]][ireps,],
                wnBirthJ = wnBirthJ[[sc]][ireps,],
                dmst = dmst[sc]
                )$tpop
            
        } ## end of reps loop

        savePop <- tpop[,,sc]

        lambdaObsMean[[sc]] <- lambdaMeanCal(nyrs = nyrs,
                                             reps = reps,
                                             savePop = savePop)

        rownames(savePop) <- paste("Year", 0:nyrs)        

        savePop <- cbind(1:reps,
                         lambdaObsMean[[sc]],
                         t(savePop))                       
       
        colnames(savePop)[1:2] <- c("Sim No.", "Lambda")
        write.csv(x = savePop,
                  file =
                  paste(wdres, paste("YearlyResultsScenario_",
                                     sc, ".csv", sep = ""),
                        sep = "/"),
                  quote = FALSE,
                  row.names = FALSE
                  )
    }

    ## add plot either adds to an existing plot or creates a new plot
    addPlot <- (svalue(add.box) == FALSE | length(dev.list())==0)
    qe = c(0,500,2000,10000) # hib sizes for plotting
    ## (based upon FWS managment goals)
    mn = svalue(grph.nm) # graph's main title
    counts = as.numeric(
        hibkey[hibkey$Hib.ID == hibno,
               paste('yr',1983:2010,sep='')])
    colr = svalue(col.box) # lines colors from GUI
    colr.wn = cols.wn[svalue(col.box,index=T)]

    endPlot(addPlot = addPlot,
            nyrs = nyrs,
            counts = counts,
            mn = mn,
            hiblimit = hiblimit,
            tpop = tpop,
            colr = colr,
            colr.wn = colr.wn,
            qe = qe,
            cino = cino,
            wdres = wdres
            )

    saveInitialCondition(
        nam = nam,
        mn = mn,
        takePar = takePar,
        enst = enst,
        dmst = dmst,
        adpr.st = adpr.st,
        nyrs = nyrs,
        tpop = tpop,
        qe = qe,
        wdres = wdres,
        lambdaTableUse = lambdaTableUse,
        lambdaObsMean = lambdaObsMean,
        reps = reps
        )

    close(pb)
}
