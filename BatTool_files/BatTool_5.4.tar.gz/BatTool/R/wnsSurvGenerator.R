wnsSurvGenerator <-
    function(wnyears,
             reps,
             nyrs,
             wnprob
             ){
        wnsSur <- matrix(data = 1, nrow = reps, ncol = nyrs + 1)
        if(min(wnyears) >= 0){
            wnsSur <- WNSdataFormat(data = wnprob,
                                    reps = reps,
                                    nyrs = nyrs,
                                    wnyears = wnyears)
        } else {
            
            wnsSurTemp <- WNSdataFormat(
                data = wnprob,
                reps = reps,
                nyrs = nyrs,
                wnyears = numeric(length(wnyears)))[, -c(1:(-wnyears[1]))]
            wnsSur[, 1:(dim(wnsSurTemp)[2])] <- wnsSurTemp
        }
        return(wnsSur)
    }
