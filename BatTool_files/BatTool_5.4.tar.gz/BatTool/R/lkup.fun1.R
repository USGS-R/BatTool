lkup.fun1 <- function(h,...){
    svalue(lmda.lo1) = min(svalue(lmda.lo1),1.5)
    svalue(lmda.up1) = min(svalue(lmda.up1),1.5)

    if(!is.na(svalue(lmda.lo1)) & !is.na(svalue(lmda.up1))){
        df <- lkup[lkup$lambda >= svalue(lmda.lo1) &
                   lkup$lambda <= svalue(lmda.up1),]
        up <- round(apply(df[1:13], 2, quantile, 0.975, na.rm = T), 2)
        lo <- round(apply(df[1:13], 2, quantile, 0.025, na.rm = T), 2)
        svalue(gCriParmValue[1,1]) = paste('[',nrow(df),']',sep = '')
        
        for(ia in 3:14){
            svalue(gCriParmValue[2,ia]) = lo[ia-1]
            svalue(gCriParmValue[3,ia]) = up[ia-1]
        }
    }
}
