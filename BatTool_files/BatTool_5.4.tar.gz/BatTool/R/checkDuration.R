checkDuration <-
function(dur, beg, nyrs){
    if( (dur + beg) > (nyrs)){
        dur <- nyrs - beg
    }
    return(dur)
}
