WNSdataFormat <-
    function(data,
             reps,
             nyrs,
             wnyears){
    wnsSur <- matrix(data = 1, nrow = reps, ncol = nyrs + 1)
    colnames(wnsSur) <- paste("Years", 1:(nyrs + 1))
    rownames(wnsSur) <- paste("Sample No.", 1:reps)

    wnyears[wnyears > nyrs] <- nyrs + 1
    wnyearsEnd <- wnyears + 21
    wnyearsEnd[wnyearsEnd > nyrs] <- nyrs + 1


    for(j in 1:reps){
        runLength <- wnyearsEnd[j] - wnyears[j]
        if(runLength > 0){
            for(i in 1:runLength){
                wnsSur[j, i + wnyears[j]] <-
                    runif(n = 1,
                          min = data[1, i ],
                          max = data[2, i ])         
            }
        }
    }
    wnsSur <- wnsSur[,-51]
    return(wnsSur)
}
    
