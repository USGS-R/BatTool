yearLambda <- function(tpop){

    nYears = dim(tpop)[2]-1
    lambdaSummary <- as.data.frame(matrix(NA, nrow = 3, ncol = nYears))
    rownames(lambdaSummary) <- c("Mean", "Lower 95%", "Upper 95%")
    colnames(lambdaSummary) <- paste("Year", 1:nYears)

    for(year in 1:nYears){
            yearLambda <- tpop[,year + 1]/tpop[,year]
            lambdaSummary[,year] <- c(
            mean(yearLambda, na.rm = TRUE),
            quantile(yearLambda, c(0.025, 0.975), na.rm = TRUE)
            )
    }


    return(lambdaSummary)
}
