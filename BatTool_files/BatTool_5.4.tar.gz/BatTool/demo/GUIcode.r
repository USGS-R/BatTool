################################################################
################################################################
## Load data and libraries 
library('gWidgetstcltk')
options("guiToolkit"="tcltk")

data(lkup) ## lookup table of parameters
hibkey         <- read.csv('./Editable_input_files_by_User/IndianaBatAndHibData.csv') ## hibernacula key
wnprob.ib      <- read.csv('./Editable_input_files_by_User/whitenoseProbabilitiesIb.csv')[,-1]
wnprob.lbb     <- read.csv('./Editable_input_files_by_User/whitenoseProbabilitiesLbb.csv')[,-1]
wnprob.other1     <- read.csv('./Editable_input_files_by_User/WNS_other_1.csv')[,-1]
wnprob.other2     <- read.csv('./Editable_input_files_by_User/WNS_other_2.csv')[,-1]
wnbeginyear    <- read.csv('./Editable_input_files_by_User/whitenoseBeginYears.csv')
ests           <- read.csv('./Editable_input_files_by_User/LambdaEstimatesFromObservations.csv')

################################################################
################################################################
## Create window to hold all data

window <- gwindow("Single Hibernaculum Matrix Projection Tool GUI",
                  visible=F)

################################################################
################################################################
## Create Hib lookup subwindow

gHib <- ggroup(container = window,
               hor = T)

bHib <- gbutton(
    'Hibernaculum number: (Click to lookup in R)',
    con = gHib,handler = hiblkup)

hib.num <- gedit('999', container = gHib,
                 coerce.with = as.numeric, width = 4,
                 handler = hib.num.fxn
                 )

hibno = svalue(hib.num)

addSpace(gHib, 5)

spop.lab = glabel(paste('Starting Population  = '), container = gHib)
spop.amt = gedit('0', container = gHib, width = 8, coerce = as.numeric)
addSpace(gHib, 5)
glabel('Hibernaculum Limit =',container = gHib)
hlim.amt = gedit('0', coerce.with = as.numeric, con = gHib, width = 7)

################################################################
################################################################
## Lambda
lambdaScn <- c('Hibernaculum', 'Complex', 'Recovery Unit', 'Species')
gLambda = gexpandgroup('Lambda', container = window, pos = 0)
visible(gLambda) = T

gLambdaScn = glayout(container = gLambda, spacing = 3)
gLambdaScn[1,1] = glabel('Scenario 1', con = gLambdaScn)
font(gLambdaScn[1,1]) = c(weight = 'bold', size = 'medium')

gLambdaScn[1,4] = glabel('Scenario 2', con = gLambdaScn)
font(gLambdaScn[1,4]) = c(weight = 'bold', size = 'medium')

gLambdaScn[3,1] = glabel('Lower: ', con = gLambdaScn)
gLambdaScn[4,1] = lmda.lo1 = gedit(
                      NA,
                      con = gLambdaScn,
                      coerce = as.numeric,
                      width = 6,
                      handler = lkup.fun1)

gLambdaScn[5,1] = glabel('Upper: ', con = gLambdaScn)
gLambdaScn[6,1] = lmda.up1 = gedit(NA,
                      con = gLambdaScn, coerce = as.numeric,
                      width = 6, handler = lkup.fun1)

gLambdaScn[2,1] = gcombobox(
              items = c("", "", "", ""),
              con = gLambdaScn,
              selected = 2,
              width = 180,
              handler = function(h,...){
                  ## Complicted operation needed to get lambdas out of dropdown list
                  lam = unlist(strsplit(svalue(h$obj), split = ' \\)'))[1]
                  lamlo = unlist(strsplit(unlist(strsplit(svalue(h$obj),
                      split = ' \\('))[2],' \\-'))[1]
                  lamup = unlist(strsplit( unlist( strsplit( svalue(h$obj),
                      split = '\\- '))[2],'\\)' ))[1]
                  svalue(lmda.up1) = min(lamup, 1.5)
                  svalue(lmda.lo1) = min(lamlo, 1.5)
                  lkup.fun1()
              })

gLambdaScn[3,4] = glabel('Lower: ', con = gLambdaScn)
gLambdaScn[4,4] = lmda.lo2 = gedit(NA, con = gLambdaScn, coerce = as.numeric,
                      width = 6, handler = lkup.fun2)
gLambdaScn[5,4] = glabel('Upper: ', con = gLambdaScn)
gLambdaScn[6,4] = lmda.up2 = gedit(NA,con = gLambdaScn,
                      coerce = as.numeric, width = 6, handler = lkup.fun2)
gLambdaScn[2,4] = gcombobox(
              items = c("", "", "", ""),
              con = gLambdaScn,
              selected = 2,
              width = 180,
              handler = function(h,...){
                  ## Complicted operation needed to get lambdas out of dropdown list
                  lam = unlist(strsplit(svalue(h$obj), split = ' \\('))[1]
                  lamlo = unlist(strsplit(unlist(strsplit(svalue(h$obj),
                      split = ' \\('))[2],' \\-'))[1]
                  lamup = unlist(strsplit( unlist( strsplit( svalue(h$obj),
                      split = '\\- '))[2],'\\)' ))[1]
                  svalue(lmda.up2) = min(lamup, 1.5)
                  svalue(lmda.lo2) = min(lamlo, 1.5)
                  lkup.fun2()
              })
              
################################################################
################################################################
## Critical Parameters

gCritParms = gexpandgroup(
    'Critical Parameter 95% Intervals',
    container = window)
visible(gCritParms) = FALSE
gCriParmValue = glayout(container = gCritParms,spacing = 3)
gCriParmValue[1,1] = glabel('',con = gCriParmValue)
enabled(gCriParmValue[1,1]) = FALSE
gCriParmValue[4,1] = glabel('',con = gCriParmValue)
enabled(gCriParmValue[4,1]) = FALSE
gCriParmValue[2,1] = glabel('Lower (Scenario 1):',con = gCriParmValue)
gCriParmValue[3,1] = glabel('Upper (Scenario 1):',con = gCriParmValue)
gCriParmValue[5,1] = glabel('Lower (Scenario 2):',con = gCriParmValue)
gCriParmValue[6,1] = glabel('Upper (Scenario 2):',con = gCriParmValue)

for(parameter in 3:14){
    gCriParmValue[1, parameter] = glabel(names(lkup)[parameter - 1],con = gCriParmValue)
    gCriParmValue[2, parameter] = glabel('',con = gCriParmValue)
    gCriParmValue[3, parameter] = glabel('',con = gCriParmValue)
    gCriParmValue[4, parameter] = glabel(names(lkup)[parameter - 1],con = gCriParmValue)
    gCriParmValue[5, parameter] = glabel('',con = gCriParmValue)
    gCriParmValue[6, parameter] = glabel('',con = gCriParmValue)
    font(gCriParmValue[1, parameter]) = c(size = 10)
    font(gCriParmValue[2, parameter]) = c(size = 10)
    font(gCriParmValue[3, parameter]) = c(size = 10)
    font(gCriParmValue[4, parameter]) = c(size = 10)
    font(gCriParmValue[5, parameter]) = c(size = 10)
    font(gCriParmValue[6, parameter]) = c(size = 10)
}

################################################################
################################################################
## Take

gTakeHeader = gexpandgroup('Female Take',container = window)
visible(gTakeHeader) = FALSE
gTake = glayout(container = gTakeHeader,spacing = 3)

gTake[1,2] = glabel('Scenario 1',   con  = gTake)
font(gTake[1,2]) = c(weight='bold', size = 'medium')
gTake[1,6] = glabel('Scenario 2',   con  = gTake)
font(gTake[1,6]) = c(weight='bold', size = 'medium')
gTake[2,2] = glabel('Take:',        con  = gTake)
gTake[2,3] = glabel('Begin Year:',  con  = gTake)

gTake[3, 3] =  witk.beg1 =  gedit(
                   paste(hibkey[hibkey$Hib.ID==hibno, "witk.beg"]),
                   con = gTake, coerce = as.numeric,
                   width = 4)

gTake[3,2] = witk.amt1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "witk.amt"]),
                 container = gTake,
                 coerce.with = as.numeric, width = 6)
gTake[3,4] = witk.dur1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "witk.dur"]),
                 con = gTake,
                 coerce = as.numeric, width = 3)
gTake[2,4] = glabel('Duration:',con=gTake, coerce = as.numeric)

gTake[4,3] = sptk.beg1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.beg"]),
                 con = gTake,
                 coerce = as.numeric, width=4)
gTake[4,2] = sptk.amt1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.amt"]),
                 container=gTake,             
                 coerce.with= as.numeric, width = 6)
gTake[4,4] = sptk.dur1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.dur"]),
                 con=gTake,
                 coerce = as.numeric, width = 3)
gTake[5,3] = sutk.beg1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sutk.beg"]),
                 con=gTake,
                 coerce = as.numeric, width = 4)
gTake[5,2] = sutk.amt1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.amt"]),,
                 container = gTake,
                 coerce.with = as.numeric, width = 6)
gTake[5,4] = sutk.dur1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.dur"]),
                 con=gTake,
                 coerce = as.numeric, width=3)

gTake[6,3] = fatk.beg1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "fatk.beg"]),
                 con = gTake,
                 coerce = as.numeric, width = 4)
gTake[6,2] = fatk.amt1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "fatk.amt"]),
                 container = gTake,
                 coerce.with = as.numeric, width = 6)
gTake[6,4] = fatk.dur1 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "fatk.dur"]),
                 con = gTake,
                 coerce = as.numeric, width = 3)

gTake[3,5]=glabel(' <-------Winter-------->   ',con = gTake)
gTake[4,5]=glabel(' <-------Spring-------->   ',con = gTake)
gTake[5,5]=glabel(' <-------Summer-------->   ',con = gTake)
gTake[6,5]=glabel(' <--------Fall--------->   ',con = gTake)

gTake[3,6] = witk.amt2=gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "witk.amt"]),
                 container = gTake,
                 coerce.with = as.numeric, width=6)
gTake[3,7] = witk.beg2=gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "witk.beg"]),
                 con=gTake, coerce=as.numeric,width=4)
gTake[3,8] = witk.dur2=gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "witk.dur"]),
                 con=gTake, coerce=as.numeric,width=3)

gTake[2,6] = glabel('Take:',con=gTake)
gTake[2,7] = glabel('Begin Year:',con=gTake)
gTake[2,8] = glabel('Duration:', con = gTake, coerce = as.numeric)

gTake[4,6] = sptk.amt2=gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.amt"]),
                 container = gTake,
                 coerce.with = as.numeric, width=6)
gTake[4,7] = sptk.beg2=gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.beg"]),
                 con=gTake,
                 coerce=as.numeric,width=4)
gTake[4,8] = sptk.dur2 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sptk.dur"]),
                 con=gTake,coerce=as.numeric,width=3)

gTake[5,6] = sutk.amt2 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sutk.amt"]),
                 container=gTake,
                 coerce.with=as.numeric,width=6)
gTake[5,7] = sutk.beg2 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sutk.beg"]),
                 con=gTake,
                 coerce=as.numeric,width=4)
gTake[5,8] = sutk.dur2 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "sutk.dur"]),
                 con=gTake,
                 coerce=as.numeric,width=3)

gTake[6,6] = fatk.amt2 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "fatk.amt"]), ,
                 container=gTake,
                 coerce.with=as.numeric,width=6)
gTake[6,7] = fatk.beg2=gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "fatk.beg"]), ,
                 con=gTake,
                 cocerce=as.numeric,width=4)
gTake[6,8] = fatk.dur2 = gedit(
                 paste(hibkey[hibkey$Hib.ID==hibno, "fatk.dur"]),
                 '0',con=gTake,
                 coerce=as.numeric,width=3)


################################################################
################################################################
## WNS

wnsScenarios = c('No WNS', 'LBB ests', 'IB ests', "Other 1", "Other 2")


gWnsHead = gexpandgroup('WNS', con = window)
visible(gWnsHead) = FALSE

gWNS         = glayout(con = gWnsHead, spacing = 3)

## Row Labels 
gWNS[4:5, 1:3] = glabel(
        'To view or change WNS survival and breeding
reduction probabilities in an R window, click on 
the buttons to the right:
(Once clicked, you must close the data editor 
 window that is opened in R before proceeding)', con = gWNS)
gWNS[7,1]    = glabel('Infection Probability:', con = gWNS)
gWNS[8,1]    = glabel('--OR-- Year of Infection:\n(year after last year of data)', con = gWNS)


## Scenario 1 column 
gWNS[4,4]      = gbutton('Scenario 1', con = gWNS, handler = wnprobs1)
gWNS[4,5]      = gcombobox(wnsScenarios,
            select = 1, con = gWNS, handler = wnprobs.fxn1, width = 50)
gWNS[6,2]      = glabel('Scenario 1:', con = gWNS)
gWNS[7,2]      = gedit(
                   '0.096', con = gWNS,
                   width = 5, coerce = as.numeric)
gWNS[8,2]      = gedit(
        'NA', con = gWNS, width = 6,
        coerce = as.numeric,
        handler = yearFxn1
)


## Scenario 2 column
gWNS[5,4]   = gbutton('Scenario 2', con = gWNS, handler = wnprobs2)
gWNS[5,5]   = gcombobox(wnsScenarios, select = 3,
                      con = gWNS, handler = wnprobs.fxn2, width = 50)
gWNS[6,3]   = glabel('Scenario 2:', con = gWNS)
gWNS[7,3]   = gedit('NA', con = gWNS,
                    width = 5, coerce = as.numeric)

gWNS[8,3]   = gedit(
        'NA', con = gWNS,
        width = 6, coerce = as.numeric,
        handler = function(h,...){
            svalue(gWNS[5,5],index = T) = 3
            wnprobs.fxn2()
            if(!is.na(svalue(h$obj))){
                svalue(gWNS[7,3]) = NA}
        }
)





## ################################################################
## ################################################################
## ## Miscellaneous 
gMisc = gexpandgroup('Other parameters',container = window)
visible(gMisc) = F
gMisca = glayout(con = gMisc,spacing = 5)
gMisca[1,2] = glabel('Scenario 1',con = gMisca)
gMisca[1,3] = glabel('Scenario 2',con = gMisca)
gMisca[2,1] = glabel('Starting Adult Pr. ',container = gMisca)
gMisca[3,1] = glabel('Environmental Stochasticity ',container = gMisca)
gMisca[4,1] = glabel('Demographic Stochasticity: ',container = gMisca)
gMisca[2,2] = adpr.amt1 = gedit('0.8',container = gMisca,
         coerce.with = as.numeric,width = 4)
gMisca[3,2] = enst.amt1 = gedit('.04',container = gMisca,
         coerce.with = as.numeric,width = 4)
gMisca[4,2] = dmst.box1 = gcheckbox(container = gMisca,
         checked = TRUE)
gMisca[2,3] = adpr.amt2 = gedit('0.8',container = gMisca,
         coerce.with = as.numeric,width = 4)
gMisca[3,3] = enst.amt2 = gedit('.04',container = gMisca,
         coerce.with = as.numeric,width = 4)
gMisca[4,3] = dmst.box2 = gcheckbox(container = gMisca,checked = TRUE)

## ################################################################
## ################################################################
## ## Graphing options

gGraph = gexpandgroup('Graphing and results options', container = window)
visible(gGraph) = F
gGrapha = glayout(con = gGraph,spacing = 0)
gGrapha[1,1] = glabel('Color:',con = gGrapha)
cols = c('black','blue','red','green')
cols.wn = c('grey','light blue','pink','light green')
gGrapha[1,2] = col.box = gcombobox(cols,con = gGrapha)
gGrapha[1,3] = glabel('      ',con = gGrapha)
gGrapha[1,4] = add.box = gcheckbox('Add to existing plot',
            checked = F,container = gGrapha,
	handler =function(h,...){
	if(svalue(h$obj) == T){enabled(grph.nm) = F}
	if(svalue(h$obj) == F){svalue(grph.nm) =
           paste(hibkey$Hibernaculum.Name[hibno.row],', ',
				hibkey$County[hibno.row],' County, ',
				hibkey$State[hibno.row],sep = '');enabled(
                                        grph.nm) = T}
	})
gGrapha[1,5] = glabel('      ',con = gGrapha)
gGrapha[1,6] = cino.box = gcheckbox('Add ',checked = T,container = gGrapha)
gGrapha[1,7] = cino.amt = gedit('95',width = 2,
            container = gGrapha,coerce.with = as.numeric)
gGrapha[1,8] = glabel('% credible intervals',container = gGrapha)
gGrapha[2,2] = glabel('Graph/Results title:',con = gGrapha)
gGrapha[2,3:8] = grph.nm = gedit('',con = gGrapha,width = 50)

## ################################################################
## ################################################################
## ## Simulation options

gSim = ggroup(container = window)
nYearsLab = glabel('Number of years to simulate ',container = gSim)
nyrs.amt = gedit('50',container = gSim, coerce.with = as.numeric,width = 5)
nSimsLab = glabel('Number of simulations to run ',container = gSim)
reps.amt = gedit('1000',container = gSim, coerce.with = as.numeric,width = 7)

################################################################
################################################################
## Run tools

gRun = ggroup(container = window)
run.but = gbutton( 'RUN', container = gRun,handler = run)
font(run.but) = c(weight = 'bold',size = 'medium')
enabled(run.but) = T

addSpace(gRun,15)
glabel('Results folder name:',con = gRun)
fnam = gedit('temp',con = gRun)

addSpace(gRun,15)
b2 = gbutton('Restore defaults',checked = F,con = gRun,
      handler = defs.reset, font = c(size = 4))
font(b2) = c(size = 'x-small')

stat.bar = gstatusbar('',con = window)
font(stat.bar) = c(weight = 'ultra-bold',size = 'large')

defs.reset()


################################################################
################################################################
## make window visible to display, last step
visible(window) = TRUE 
